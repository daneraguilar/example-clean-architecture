package co.com.ceiba.mobile.pruebadeingreso.view;

public class Constants {
    public static final int TIME_OUT = 10000;
}
